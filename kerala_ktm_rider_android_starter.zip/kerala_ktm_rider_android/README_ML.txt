KERALA KTM RIDER – ANDROID APP STARTER
======================================

ഈ ZIP-ൽ 3D browser game-ന്റെ Android wrapper project ആണ്.
ഇത് തയ്യാറായ APK അല്ല. APK build ചെയ്യാൻ Windows/Mac/Linux കമ്പ്യൂട്ടറിൽ
Node.js, Android Studio, Android SDK എന്നിവ വേണം.

ആവശ്യമായവ:
1. Node.js (LTS)
2. Android Studio + Android SDK
3. USB debugging enabled Android phone (പരീക്ഷിക്കാൻ)

Build ചെയ്യാനുള്ള ഘട്ടങ്ങൾ:
1. ZIP extract ചെയ്യുക.
2. ഈ project folder-ൽ Terminal / Command Prompt തുറക്കുക.
3. `npm install` പ്രവർത്തിപ്പിക്കുക.
4. `npx cap add android` പ്രവർത്തിപ്പിക്കുക.
5. `npx cap sync android` പ്രവർത്തിപ്പിക്കുക.
6. `npx cap open android` പ്രവർത്തിപ്പിക്കുക.
7. Android Studio-ൽ Gradle sync പൂർത്തിയാകാൻ കാത്തിരിക്കുക.
8. Build > Build Bundle(s) / APK(s) > Build APK(s) തിരഞ്ഞെടുക്കുക.

ശ്രദ്ധിക്കുക:
- 3D game graphics-ന് ഇപ്പോൾ internet connection ആവശ്യമാണ് (Three.js CDN).
- ഈ project ഒരു starter wrapper ആണ്; production release-ിന് മുമ്പ്
  device testing, performance tuning, privacy policy, app signing,
  Play Store requirements എന്നിവ പൂർത്തിയാക്കണം.
- KTM ഒരു ട്രേഡ്മാർക്ക് ആണ്. Public release ചെയ്യുമ്പോൾ ആവശ്യമായ
  brand permissions ഇല്ലെങ്കിൽ generic/original bike branding ഉപയോഗിക്കുക.
